# BotFather and Telegram setup

1. Open @BotFather in Telegram and send /newbot. Pick a name (e.g. Zainul FX Journal) and a username ending in "bot". Save the token it gives you into your local .env (never commit it).
2. Send /setmenubutton, choose your bot, then send your HTTPS app URL (e.g. https://your-host.example/). Give the button the text "Open journal".
3. Optional: send /newapp to register a Mini App with a name, description, photo and the same HTTPS URL. This gives a shareable t.me link.
4. Test: open your bot, tap the menu button. The app opens inside Telegram.

Mini Apps require HTTPS. Plain http://localhost works only in a desktop browser, not inside Telegram.

# Deployment (any free static HTTPS host)

The app is static: upload the whole project folder (index.html, css/, js/, assets/) as-is. No build step.

Options: Cloudflare Pages, Netlify, GitHub Pages, Vercel (static). For each, point the build output to the project root (no build command). Once deployed, copy the HTTPS URL into BotFather (step 2 above).

Do not deploy the tests/ or docs/ folders to a public site if you prefer them private. They are harmless but unnecessary.
